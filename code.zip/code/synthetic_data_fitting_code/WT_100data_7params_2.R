
# Set up a personal library path
.libPaths("/home/zc527/R/x86_64-pc-linux-gnu-library/4.4")
library(nloptr)
library(RcppArmadillo)
library(Rcpp)
library(estimatePMR)
library(parallel)

file_list <- list.files(pattern = "synthetic_tot.*\\.csv$", full.names = TRUE)
data_list <- lapply(file_list, read.csv)

# 2. Define optimization function (self-contained)
optim_fun <- function(i) {
    current_data <- data_list[[i]]
    
    initCount = current_data$Circ[min(which(is.finite(current_data$Circ)))]
    
    # betaShape, offset, R, n, I0, inflec, ring duration
    lower_bounds = c(log(-log(1 - 1e-10)),log(-log(1 - 1e-10)),log(1), log(log(4)/2), log(initCount/10), log(-log(1 - 1e-10)), log(-log(1 - 1e-10)))
    upper_bounds = c(log(-log(3/1601)),log(-log(0 + 1e-10)),log(20), log(log(200)/2), log(initCount*10), log(-log(0 + 1e-10)), log(-log(0 + 1e-10)))
    
    
    result = winnowing_optim(archer_fitN_odeint,
                             lower_bounds,
                             upper_bounds,
                             fn_args = list(data = current_data, pfCycleLength = 24, geno = F),
                             n_bevals = 10000L,
                             n_boxes = 5000L,
                             n_outputs = c(500L, 20L, 1L), # fine, polished, returned
                             controls = list(list(maxeval = 100, xtol_rel = 1e-4),
                                             list(maxeval = 500, xtol_rel = 1e-6),
                                             list(maxeval = 1000, xtol_rel = 1e-8)),
                             optimizers = c(nloptr::neldermead,
                                            nloptr::neldermead,
                                            nloptr::neldermead),
                             file_names = NULL,
                             overwrite = TRUE,
                             na_stop = FALSE)
    
    return(list(par = result[[1]]$par, value = result[[1]]$value))
}


# 3. Function that simulate ring proportion at high resolution and store all outputs
archer_postprocess_fun <- function(j, data_list, detest, idx) {
    
    i <- idx[j]                     # actual dataset index
    current_data <- data_list[[i]]
    
    ode_output <- archer_fitN_odeint(
        detest[[j]]$par,
        current_data,
        output_full_return = TRUE,
        geno = FALSE,
        pfCycleLength = 24
    )
    
    parms <- extract_parms(detest[[j]]$par, pfCycleLength = 24)
    n <- parms[4]
    ring_duration <- parms[8]
    
    circ.iRBC <- rowSums(ode_output[, 2:(n + 1), drop = FALSE])
    seq.iRBC  <- rowSums(ode_output[, (n + 2):(2*n + 1), drop = FALSE])
    
    ring_last_stage <- round(ring_duration / 24 * n) + 1
    ring_prop_estim <- rowSums(ode_output[, 2:ring_last_stage, drop = FALSE]) /
        circ.iRBC
    
    archer.output <- data.frame(
        circ_iRBC = circ.iRBC,
        seq_iRBC = seq.iRBC,
        ring_prop_estim = ring_prop_estim
    )
    
    write.csv(archer.output,
              paste0("syn_data", i, "_output.csv"),
              row.names = FALSE)
    
    archer.output
}

# 4. Set up parallel cluster
cl <- makeCluster(25)

# 5. Export ALL required objects
clusterExport(cl, varlist = c("data_list", "archer_fitN_odeint", 
                              "winnowing_optim", "extract_parms"))

# 6. Load packages and verify environment on workers
clusterEvalQ(cl, {
    library(nloptr)
    library(Rcpp)
    library(estimatePMR)
})

idx <- 26:50

detest <- clusterApplyLB(cl, idx, optim_fun)

# 7. Process results
out <- do.call(rbind, lapply(detest, function(x) {
    data.frame(
        betaShape = extract_parms(x$par, pfCycleLength = 24)[1],
        offset = extract_parms(x$par, pfCycleLength = 24)[2],
        R = extract_parms(x$par, pfCycleLength = 24)[3],
        n = extract_parms(x$par, pfCycleLength = 24)[4],
        I0 = extract_parms(x$par, pfCycleLength = 24)[5],
        inflec = extract_parms(x$par, pfCycleLength = 24)[7],
        ring_length = extract_parms(x$par, pfCycleLength = 24)[8],
        sse = x$value
    )
}))

# 8. store all outputs together
archer_output_list <- clusterApplyLB(cl, seq_along(idx), archer_postprocess_fun,
                                     data_list = data_list, detest = detest, idx = idx)



write.table(out, file = "winnow_cpp_100data1_7params_2")


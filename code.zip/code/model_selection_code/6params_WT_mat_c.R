
# Set up a personal library path
.libPaths("/home/zc527/R/x86_64-pc-linux-gnu-library/4.4")
library(nloptr)
library(RcppArmadillo)
library(Rcpp)
library(estimatePMR)

dataset <- read.csv("WT_matched.1.csv")

initCount = dataset$Circ[min(which(is.finite(dataset$Circ)))]

# Bounds for the following parameters: betaShape, offset, R, n, I0, pfCycleLength
lower_bounds = c(log(-log(1 - 1e-10)), log(-log(1 - 1e-10)), log(1), log(log(4)/2),
                 log(initCount/10), log(-log(1 - 1e-10)))
upper_bounds = c(log(-log(3/1601)), log(-log(0 + 1e-10)), log(20), log(log(500)/2),
                 log(initCount*10), log(-log(0 + 1e-10)))

detest = winnowing_optim(archer_fitN_odeint,
                         lower_bounds,
                         upper_bounds,
                         fn_args = list(data = dataset, inflec = 18.5802 / 2.0, ring_duration = 12, geno = F),
                         n_bevals = 1000L,
                         n_boxes = 1000L, 
                         n_outputs = c(100L, 20L, 3L), # fine, polished, returned
                         controls = list(list(maxeval = 1000, xtol_rel = 1e-4),
                                         list(maxeval = 5000, xtol_rel = 1e-6),
                                         list(maxeval = 10000, xtol_rel = 1e-8)),
                         optimizers = c(nloptr::neldermead,
                                        nloptr::neldermead,
                                        nloptr::neldermead),
                         file_names = NULL,
                         overwrite = TRUE,
                         na_stop = FALSE,
                         verbose = F)


# full resolution ode output
ode_output = archer_fitN_odeint(detest[[3]]$par, dataset, output_full_return = T, geno = F,
                                inflec = 18.5802 / 2.0, ring_duration = 12,)

# simulating ring proportion estimation (full resolution)
n = extract_parms(detest[[3]]$par, inflec = 18.5802 / 2.0, ring_duration = 12)[4]
ring_duration = 12
pfCycleLength = extract_parms(detest[[3]]$par, inflec = 18.5802 / 2.0, ring_duration = 12)[6]

circ.iRBC = apply(ode_output[ , 2:(n + 1)],1,sum)
seq.iRBC = apply(ode_output[ , (n + 2):(2*n + 1)],1,sum)

ring_last_stage = round(ring_duration/pfCycleLength * n) + 1
circ_ring_tot = apply(ode_output[,2:ring_last_stage],1,sum)
ring_prop_estim = circ_ring_tot/circ.iRBC

# storing everything together
archer.output = data.frame(circ_iRBC = circ.iRBC,
                           seq_iRBC  = seq.iRBC,
                           ring_prop_estim = ring_prop_estim)

# storing transformed output
detest

detest[[1]]$par = extract_parms(detest[[1]]$par, inflec = 18.5802 / 2.0, ring_duration = 12)
detest[[2]]$par = extract_parms(detest[[2]]$par, inflec = 18.5802 / 2.0, ring_duration = 12)
detest[[3]]$par = extract_parms(detest[[3]]$par, inflec = 18.5802 / 2.0, ring_duration = 12)


write.table(archer.output, file = "6params_WT_mat_c.output")
write.table(detest, file = "6params_WT_mat_c")

